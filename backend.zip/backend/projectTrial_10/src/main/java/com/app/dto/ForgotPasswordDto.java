package com.app.dto;




public class ForgotPasswordDto {
	// data members MUST MATCH with JSON prop names
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
