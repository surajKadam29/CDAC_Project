package com.app.service;

import com.app.dto.CartItemDto;
import com.app.pojos.CartItem;


public interface CartItemService {

	String addCartItem(CartItemDto newCartItem);

	
	
	
}
