package com.app.pojos;

public enum CardType {
CREDIT,DEBIT,SAVING;
}
