package com.app.pojos;

public enum Role {
	 CUSTOMER,ADMIN;
}

